﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChupButton : MonoBehaviour
{
    public void ChupacabraLevel()
    {
        SceneManager.LoadScene("BaseLevel"); ;
    }
}
